$ErrorActionPreference = "Stop"

$ollama = Join-Path $env:LOCALAPPDATA "Programs\Ollama\ollama.exe"
if (-not (Test-Path $ollama)) {
    $ollama = "ollama.exe"
    if (-not (Get-Command $ollama -ErrorAction SilentlyContinue)) {
        Write-Host "Installing Ollama..."
        winget install --id Ollama.Ollama --exact --accept-source-agreements --accept-package-agreements
        $ollama = Join-Path $env:LOCALAPPDATA "Programs\Ollama\ollama.exe"
    }
}

Write-Host "Downloading the local coding model..."
& $ollama pull qwen2.5-coder:3b
if ($LASTEXITCODE -ne 0) {
    throw "Ollama model download failed."
}

Write-Host "Installation complete. Start raylib-test.exe; Ollama will start and stop with it."