#define WIN32_LEAN_AND_MEAN
#define NOGDI
#define CloseWindow Win32CloseWindow
#define DrawTextEx Win32DrawTextEx
#define DrawText Win32DrawText
#define ShowCursor Win32ShowCursor
#define LoadImage Win32LoadImage
#include <windows.h>
#include <winhttp.h>
#undef CloseWindow
#undef DrawTextEx
#undef DrawText
#undef ShowCursor
#undef LoadImage
#include "raylib.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define WINDOW_WIDTH 800
#define WINDOW_HEIGHT 600
#define MAX_CODE_LENGTH 4096
#define LANGUAGE_COUNT 6
#define UI_LANGUAGE_COUNT 5

static const char *languages[LANGUAGE_COUNT] = {
    "C", "Python", "JavaScript", "Java", "C++", "C#"
};

typedef struct UiText {
    const char *title;
    const char *subtitle;
    const char *source;
    const char *target;
    const char *translated;
    const char *placeholderInput;
    const char *placeholderOutput;
    const char *translate;
    const char *footer;
} UiText;

static const char *uiLanguages[UI_LANGUAGE_COUNT] = {
    "English", "Cesky", "Espanol", "Deutsch", "Francais"
};

static const UiText uiTexts[UI_LANGUAGE_COUNT] = {
    {
        "AI CODE TRANSLATOR", "Prepare code for an AI translation request", "SOURCE CODE",
        "TARGET LANGUAGE", "TRANSLATED CODE", "Type or paste code...", "Translation appears here...",
        "TRANSLATE", "Click the source panel, type code, choose a language, then translate."
    },
    {
        "AI PREKLADAC KODU", "Priprav kod pro pozadavek umele inteligenci", "ZDROJOVY KOD",
        "CILOVY JAZYK", "PRELOZENY KOD", "Napiste nebo vlozte kod...", "Preklad se objevi zde...",
        "PRELOZIT", "Kliknete do panelu, napiste kod, vyberte jazyk a prelozte."
    },
    {
        "TRADUCTOR DE CODIGO IA", "Prepara el codigo para una solicitud de IA", "CODIGO FUENTE",
        "LENGUAJE DESTINO", "CODIGO TRADUCIDO", "Escribe o pega el codigo...", "La traduccion aparece aqui...",
        "TRADUCIR", "Haz clic, escribe codigo, elige un lenguaje y traduce."
    },
    {
        "KI-CODE-UEBERSETZER", "Code fuer eine KI-Anfrage vorbereiten", "QUELLCODE",
        "ZIELSPRACHE", "UEBERSETZTER CODE", "Code eingeben oder einfuegen...", "Die Uebersetzung erscheint hier...",
        "UEBERSETZEN", "Klicken, Code eingeben, Sprache waehlen und uebersetzen."
    },
    {
        "TRADUCTEUR DE CODE IA", "Preparez le code pour une demande IA", "CODE SOURCE",
        "LANGAGE CIBLE", "CODE TRADUIT", "Saisissez ou collez le code...", "La traduction apparait ici...",
        "TRADUIRE", "Cliquez, saisissez le code, choisissez une langue et traduisez."
    }
};

static char translatedOutput[MAX_CODE_LENGTH];
static Font uiFont;
static HANDLE ollamaProcess = NULL;
static HANDLE translationThread = NULL;
static volatile LONG translationState = 0;
static char translationInput[MAX_CODE_LENGTH];
static char translationTarget[32];

static void DrawUiText(const char *text, int x, int y, int fontSize, Color color)
{
    DrawTextEx(uiFont, text, (Vector2){ (float)x, (float)y }, (float)fontSize, 1.0f, color);
}

static Image CreateApplicationIcon(void)
{
    Image icon = GenImageColor(64, 64, (Color){ 18, 24, 38, 255 });
    Color cyan = (Color){ 120, 211, 190, 255 };
    Color orange = (Color){ 224, 139, 54, 255 };
    Color codeWhite = (Color){ 235, 241, 248, 255 };
    Color codeGray = (Color){ 82, 101, 130, 255 };

    ImageDrawRectangle(&icon, 3, 5, 58, 54, codeGray);
    ImageDrawRectangle(&icon, 7, 9, 50, 46, (Color){ 25, 34, 51, 255 });
    ImageDrawRectangle(&icon, 3, 5, 58, 10, cyan);
    ImageDrawCircle(&icon, 11, 10, 2, orange);
    ImageDrawCircle(&icon, 18, 10, 2, codeWhite);
    ImageDrawCircle(&icon, 25, 10, 2, codeWhite);
    ImageDrawLineEx(&icon, (Vector2){ 17, 25 }, (Vector2){ 27, 32 }, 4.0f, orange);
    ImageDrawLineEx(&icon, (Vector2){ 27, 32 }, (Vector2){ 17, 39 }, 4.0f, orange);
    ImageDrawLineEx(&icon, (Vector2){ 34, 42 }, (Vector2){ 49, 42 }, 4.0f, orange);
    ImageDrawLineEx(&icon, (Vector2){ 39, 25 }, (Vector2){ 49, 32 }, 4.0f, orange);
    ImageDrawLineEx(&icon, (Vector2){ 49, 32 }, (Vector2){ 39, 39 }, 4.0f, orange);
    return icon;
}

static void SetErrorMessage(const char *message)
{
    snprintf(translatedOutput, sizeof(translatedOutput), "%s", message);
}

static void StartOllamaServer(void)
{
    wchar_t commandLine[512];
    wchar_t localOllamaPath[MAX_PATH];
    const wchar_t *installedPaths[2];
    const wchar_t *executable = NULL;

    swprintf(localOllamaPath, sizeof(localOllamaPath) / sizeof(localOllamaPath[0]),
        L"%ls\\Programs\\Ollama\\ollama.exe", _wgetenv(L"LOCALAPPDATA"));
    installedPaths[0] = localOllamaPath;
    installedPaths[1] = L"C:\\Program Files\\Ollama\\ollama.exe";

    for (int index = 0; index < (int)(sizeof(installedPaths) / sizeof(installedPaths[0])); index++) {
        if (GetFileAttributesW(installedPaths[index]) != INVALID_FILE_ATTRIBUTES) {
            executable = installedPaths[index];
            break;
        }
    }

    if (executable != NULL) {
        swprintf(commandLine, sizeof(commandLine) / sizeof(commandLine[0]), L"\"%ls\" serve", executable);
    } else {
        swprintf(commandLine, sizeof(commandLine) / sizeof(commandLine[0]), L"ollama.exe serve");
    }

    STARTUPINFOW startupInfo = { 0 };
    PROCESS_INFORMATION processInfo = { 0 };
    startupInfo.cb = sizeof(startupInfo);

    if (CreateProcessW(NULL, commandLine, NULL, NULL, FALSE, CREATE_NO_WINDOW, NULL, NULL,
                       &startupInfo, &processInfo)) {
        CloseHandle(processInfo.hThread);
        ollamaProcess = processInfo.hProcess;
    }
}

static void StopOllamaServer(void)
{
    if (ollamaProcess != NULL) {
        DWORD exitCode = STILL_ACTIVE;
        if (GetExitCodeProcess(ollamaProcess, &exitCode) && exitCode == STILL_ACTIVE) {
            TerminateProcess(ollamaProcess, 0);
            WaitForSingleObject(ollamaProcess, 2000);
        }
        CloseHandle(ollamaProcess);
        ollamaProcess = NULL;
    }
}

static int AppendJsonEscaped(char *json, int *length, int capacity, const char *text)
{
    for (int index = 0; text[index] != '\0'; index++) {
        char character = text[index];
        const char *escaped = NULL;

        if (character == '"') escaped = "\\\"";
        else if (character == '\\') escaped = "\\\\";
        else if (character == '\n') escaped = "\\n";
        else if (character == '\r') escaped = "\\r";
        else if (character == '\t') escaped = "\\t";

        if (escaped != NULL) {
            int escapedLength = (int)strlen(escaped);
            if (*length + escapedLength >= capacity - 1) return 0;
            memcpy(json + *length, escaped, escapedLength);
            *length += escapedLength;
        } else {
            if (*length >= capacity - 1) return 0;
            json[(*length)++] = character;
        }
    }
    json[*length] = '\0';
    return 1;
}

static int ExtractJsonResponse(const char *json, char *output, int outputSize)
{
    const char *value = strstr(json, "\"response\":\"");
    if (value == NULL) return 0;
    value += strlen("\"response\":\"");

    int outputLength = 0;
    while (*value != '\0' && *value != '"' && outputLength < outputSize - 1) {
        if (*value == '\\') {
            value++;
            if (*value == 'n') output[outputLength++] = '\n';
            else if (*value == 'r') output[outputLength++] = '\r';
            else if (*value == 't') output[outputLength++] = '\t';
            else if (*value != '\0') output[outputLength++] = *value;
        } else {
            output[outputLength++] = *value;
        }
        value++;
    }
    output[outputLength] = '\0';
    return 1;
}

static int TranslateCodeWithAI(const char *inputCode, const char *targetLanguage)
{
    char prompt[MAX_CODE_LENGTH + 512];
    char requestBody[MAX_CODE_LENGTH + 1024];
    char responseBody[16384] = "";
    int promptLength;

    if (inputCode[0] == '\0') {
        SetErrorMessage("Enter source code first.");
        return 0;
    }

    promptLength = snprintf(prompt, sizeof(prompt),
        "Translate the following source code to %s. Return only the translated code, without markdown fences or explanations.\n\n%s",
        targetLanguage, inputCode);
    if (promptLength < 0 || promptLength >= (int)sizeof(prompt)) {
        SetErrorMessage("The source code is too long.");
        return 0;
    }

    int requestLength = snprintf(requestBody, sizeof(requestBody), "{\"model\":\"qwen2.5-coder:3b\",\"prompt\":\"");
    if (requestLength < 0 || !AppendJsonEscaped(requestBody, &requestLength, sizeof(requestBody), prompt) ||
        requestLength + 20 >= (int)sizeof(requestBody)) {
        SetErrorMessage("The request is too long.");
        return 0;
    }
    requestLength += snprintf(requestBody + requestLength, sizeof(requestBody) - requestLength, "\",\"stream\":false}");

    HINTERNET session = WinHttpOpen(L"RaylibCodeTranslator/1.0", WINHTTP_ACCESS_TYPE_NO_PROXY, NULL, NULL, 0);
    if (session != NULL) {
        WinHttpSetTimeouts(session, 3000, 3000, 3000, 30000);
    }
    HINTERNET connection = session != NULL ? WinHttpConnect(session, L"localhost", 11434, 0) : NULL;
    HINTERNET request = connection != NULL ? WinHttpOpenRequest(connection, L"POST", L"/api/generate", NULL, NULL, NULL, 0) : NULL;
    const wchar_t *headers = L"Content-Type: application/json\r\n";
    BOOL sent = request != NULL && WinHttpSendRequest(request, headers, (DWORD)-1L, requestBody,
        (DWORD)requestLength, (DWORD)requestLength, 0);
    BOOL received = sent && WinHttpReceiveResponse(request, NULL);
    DWORD statusCode = 0;
    DWORD statusSize = sizeof(statusCode);
    if (received) {
        WinHttpQueryHeaders(request, WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER,
            WINHTTP_HEADER_NAME_BY_INDEX, &statusCode, &statusSize, WINHTTP_NO_HEADER_INDEX);
    }

    DWORD bytesAvailable = 0;
    DWORD bytesRead = 0;
    int responseLength = 0;
    while (received && statusCode == 200 && responseLength < (int)sizeof(responseBody) - 1 &&
           WinHttpQueryDataAvailable(request, &bytesAvailable) && bytesAvailable > 0) {
        DWORD amount = bytesAvailable;
        if (amount > (DWORD)(sizeof(responseBody) - 1 - responseLength)) {
            amount = sizeof(responseBody) - 1 - responseLength;
        }
        if (!WinHttpReadData(request, responseBody + responseLength, amount, &bytesRead) || bytesRead == 0) break;
        responseLength += (int)bytesRead;
    }
    responseBody[responseLength] = '\0';

    if (request != NULL) WinHttpCloseHandle(request);
    if (connection != NULL) WinHttpCloseHandle(connection);
    if (session != NULL) WinHttpCloseHandle(session);

    if (statusCode != 200) {
        SetErrorMessage("Ollama is not running or the model is missing.");
        return 0;
    }
    if (!ExtractJsonResponse(responseBody, translatedOutput, sizeof(translatedOutput))) {
        SetErrorMessage("Ollama returned an invalid response.");
        return 0;
    }
    return 1;
}

static DWORD WINAPI TranslationThreadProc(LPVOID unused)
{
    (void)unused;
    TranslateCodeWithAI(translationInput, translationTarget);
    InterlockedExchange(&translationState, 2);
    return 0;
}

static void AppendCharacter(char *text, int *length, int character)
{
    if (*length < MAX_CODE_LENGTH - 1 && character >= 32 && character <= 126) {
        text[*length] = (char)character;
        (*length)++;
        text[*length] = '\0';
    }
}

static void AppendClipboard(char *text, int *length)
{
    const char *clipboard = GetClipboardText();
    if (clipboard != NULL) {
        for (int index = 0; clipboard[index] != '\0'; index++) {
            if (clipboard[index] == '\n' || clipboard[index] == '\r' ||
                (clipboard[index] >= 32 && clipboard[index] <= 126)) {
                AppendCharacter(text, length, clipboard[index] == '\r' ? ' ' : clipboard[index]);
            }
        }
    }
}

static void RemoveLastCharacter(char *text, int *length)
{
    if (*length > 0) {
        (*length)--;
        text[*length] = '\0';
    }
}

static void DrawMultilineText(const char *text, Rectangle area, int fontSize, Color color)
{
    char line[256];
    int lineLength = 0;
    int lineNumber = 0;

    for (int index = 0; ; index++) {
        char character = text[index];
        if (character == '\n' || character == '\0') {
            line[lineLength] = '\0';
            DrawUiText(line, (int)area.x, (int)area.y + lineNumber * (fontSize + 5), fontSize, color);
            lineLength = 0;
            lineNumber++;
            if (character == '\0' || area.y + lineNumber * (fontSize + 5) > area.y + area.height - fontSize) {
                break;
            }
        } else {
            if (lineLength < 255) {
                line[lineLength++] = character;
                line[lineLength] = '\0';

                if (MeasureTextEx(uiFont, line, (float)fontSize, 1.0f).x > area.width && lineLength > 1) {
                    line[lineLength - 1] = '\0';
                    DrawUiText(line, (int)area.x, (int)area.y + lineNumber * (fontSize + 5), fontSize, color);
                    lineNumber++;
                    line[0] = character;
                    line[1] = '\0';
                    lineLength = 1;
                    if (area.y + lineNumber * (fontSize + 5) > area.y + area.height - fontSize) {
                        break;
                    }
                }
            }
        }
    }
}

int main(void)
{
    char inputCode[MAX_CODE_LENGTH] = "";
    int inputLength = 0;
    int selectedLanguage = 0;
    int selectedUiLanguage = 0;
    bool inputFocused = true;
    bool dropdownOpen = false;
    bool uiLanguageOpen = false;
    bool hasTranslation = false;

    Rectangle inputBox = { 24, 116, 236, 380 };
    Rectangle dropdownBox = { 292, 176, 216, 44 };
    Rectangle translateButton = { 292, 250, 216, 56 };
    Rectangle outputBox = { 540, 116, 236, 380 };
    Rectangle uiLanguageBox = { 616, 22, 160, 34 };
    Image applicationIcon;

    InitWindow(WINDOW_WIDTH, WINDOW_HEIGHT, "AI Code Translator");
    applicationIcon = CreateApplicationIcon();
    SetWindowIcon(applicationIcon);
    StartOllamaServer();
    uiFont = LoadFontEx("C:/Windows/Fonts/segoeuib.ttf", 32, NULL, 0);
    if (uiFont.texture.id == 0) {
        uiFont = GetFontDefault();
    }
    SetTargetFPS(60);

    while (!WindowShouldClose()) {
        Vector2 mouse = GetMousePosition();

        if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) {
            if (CheckCollisionPointRec(mouse, inputBox)) {
                inputFocused = true;
            } else if (CheckCollisionPointRec(mouse, uiLanguageBox)) {
                uiLanguageOpen = !uiLanguageOpen;
                dropdownOpen = false;
                inputFocused = false;
            } else if (CheckCollisionPointRec(mouse, dropdownBox)) {
                dropdownOpen = !dropdownOpen;
                uiLanguageOpen = false;
                inputFocused = false;
            } else if (uiLanguageOpen) {
                for (int index = 0; index < UI_LANGUAGE_COUNT; index++) {
                    Rectangle option = { uiLanguageBox.x, uiLanguageBox.y + uiLanguageBox.height * (index + 1), uiLanguageBox.width, uiLanguageBox.height };
                    if (CheckCollisionPointRec(mouse, option)) {
                        selectedUiLanguage = index;
                        break;
                    }
                }
                uiLanguageOpen = false;
            } else if (dropdownOpen) {
                for (int index = 0; index < LANGUAGE_COUNT; index++) {
                    Rectangle option = { dropdownBox.x, dropdownBox.y + dropdownBox.height * (index + 1), dropdownBox.width, dropdownBox.height };
                    if (CheckCollisionPointRec(mouse, option)) {
                        selectedLanguage = index;
                        break;
                    }
                }
                dropdownOpen = false;
            } else if (CheckCollisionPointRec(mouse, translateButton)) {
                hasTranslation = true;
                inputFocused = false;
                if (translationState != 1) {
                    if (translationThread != NULL) {
                        CloseHandle(translationThread);
                        translationThread = NULL;
                    }
                    snprintf(translationInput, sizeof(translationInput), "%s", inputCode);
                    snprintf(translationTarget, sizeof(translationTarget), "%s", languages[selectedLanguage]);
                    snprintf(translatedOutput, sizeof(translatedOutput), "Translating...");
                    InterlockedExchange(&translationState, 1);
                    translationThread = CreateThread(NULL, 0, TranslationThreadProc, NULL, 0, NULL);
                    if (translationThread == NULL) {
                        SetErrorMessage("Could not start translation thread.");
                        InterlockedExchange(&translationState, 2);
                    }
                }
            } else {
                inputFocused = false;
                dropdownOpen = false;
                uiLanguageOpen = false;
            }
        }

        if (inputFocused && !dropdownOpen) {
            int character = GetCharPressed();
            while (character > 0) {
                AppendCharacter(inputCode, &inputLength, character);
                character = GetCharPressed();
            }
            if (IsKeyPressed(KEY_BACKSPACE)) {
                RemoveLastCharacter(inputCode, &inputLength);
            }
            if (IsKeyDown(KEY_LEFT_CONTROL) && IsKeyPressed(KEY_V)) {
                AppendClipboard(inputCode, &inputLength);
            }
        }

        BeginDrawing();
        ClearBackground((Color){ 18, 24, 38, 255 });
        const UiText *text = &uiTexts[selectedUiLanguage];
        DrawUiText(text->title, 24, 24, 30, RAYWHITE);
        DrawUiText(text->subtitle, 26, 62, 18, (Color){ 155, 169, 190, 255 });
        DrawUiText(text->source, 24, 91, 16, (Color){ 120, 211, 190, 255 });
        DrawUiText(text->target, 292, 145, 16, (Color){ 120, 211, 190, 255 });
        DrawUiText(text->translated, 540, 91, 16, (Color){ 120, 211, 190, 255 });

        DrawRectangleRounded(uiLanguageBox, 0.12f, 8, (Color){ 40, 52, 74, 255 });
        DrawRectangleLinesEx(uiLanguageBox, 2, uiLanguageOpen ? (Color){ 120, 211, 190, 255 } : (Color){ 82, 101, 130, 255 });
        DrawUiText(uiLanguages[selectedUiLanguage], (int)uiLanguageBox.x + 10, (int)uiLanguageBox.y + 6, 16, RAYWHITE);
        DrawUiText(uiLanguageOpen ? "^" : "v", (int)uiLanguageBox.x + 142, (int)uiLanguageBox.y + 6, 16, (Color){ 180, 193, 212, 255 });

        DrawRectangleRounded(inputBox, 0.08f, 8, (Color){ 29, 38, 56, 255 });
        DrawRectangleLinesEx(inputBox, 2, inputFocused ? (Color){ 120, 211, 190, 255 } : (Color){ 64, 79, 104, 255 });
        if (inputCode[0] == '\0') {
            DrawUiText(text->placeholderInput, (int)inputBox.x + 14, (int)inputBox.y + 16, 18, (Color){ 115, 128, 151, 255 });
        } else {
            BeginScissorMode((int)inputBox.x + 12, (int)inputBox.y + 12, (int)inputBox.width - 24, (int)inputBox.height - 24);
            DrawMultilineText(inputCode, (Rectangle){ inputBox.x + 14, inputBox.y + 14, inputBox.width - 28, inputBox.height - 28 }, 17, RAYWHITE);
            EndScissorMode();
        }

        DrawRectangleRounded(dropdownBox, 0.12f, 8, (Color){ 40, 52, 74, 255 });
        DrawRectangleLinesEx(dropdownBox, 2, dropdownOpen ? (Color){ 120, 211, 190, 255 } : (Color){ 82, 101, 130, 255 });
        DrawUiText(languages[selectedLanguage], (int)dropdownBox.x + 14, (int)dropdownBox.y + 10, 20, RAYWHITE);
        DrawUiText(dropdownOpen ? "^" : "v", (int)dropdownBox.x + dropdownBox.width - 28, (int)dropdownBox.y + 10, 20, (Color){ 180, 193, 212, 255 });

        DrawRectangleRounded(translateButton, 0.12f, 8, CheckCollisionPointRec(mouse, translateButton) ? (Color){ 244, 173, 78, 255 } : (Color){ 224, 139, 54, 255 });
        DrawUiText(text->translate, (int)translateButton.x + 49, (int)translateButton.y + 16, 22, (Color){ 24, 29, 40, 255 });

        DrawRectangleRounded(outputBox, 0.08f, 8, (Color){ 29, 38, 56, 255 });
        DrawRectangleLinesEx(outputBox, 2, (Color){ 64, 79, 104, 255 });
        if (hasTranslation && translationState == 1) {
            DrawUiText("Translating with Ollama...", (int)outputBox.x + 14, (int)outputBox.y + 16, 18, (Color){ 115, 128, 151, 255 });
        } else if (hasTranslation) {
            BeginScissorMode((int)outputBox.x + 12, (int)outputBox.y + 12, (int)outputBox.width - 24, (int)outputBox.height - 24);
            DrawMultilineText(translatedOutput, (Rectangle){ outputBox.x + 14, outputBox.y + 14, outputBox.width - 28, outputBox.height - 28 }, 16, RAYWHITE);
            EndScissorMode();
        } else {
            DrawUiText(text->placeholderOutput, (int)outputBox.x + 14, (int)outputBox.y + 16, 18, (Color){ 115, 128, 151, 255 });
        }

        if (dropdownOpen) {
            for (int index = 0; index < LANGUAGE_COUNT; index++) {
                Rectangle option = { dropdownBox.x, dropdownBox.y + dropdownBox.height * (index + 1), dropdownBox.width, dropdownBox.height };
                DrawRectangleRec(option, CheckCollisionPointRec(mouse, option) ? (Color){ 63, 82, 111, 255 } : (Color){ 45, 59, 83, 255 });
                DrawUiText(languages[index], (int)option.x + 14, (int)option.y + 10, 19, RAYWHITE);
            }
        }

        if (uiLanguageOpen) {
            for (int index = 0; index < UI_LANGUAGE_COUNT; index++) {
                Rectangle option = { uiLanguageBox.x, uiLanguageBox.y + uiLanguageBox.height * (index + 1), uiLanguageBox.width, uiLanguageBox.height };
                DrawRectangleRec(option, CheckCollisionPointRec(mouse, option) ? (Color){ 63, 82, 111, 255 } : (Color){ 45, 59, 83, 255 });
                DrawUiText(uiLanguages[index], (int)option.x + 10, (int)option.y + 6, 16, RAYWHITE);
            }
        }

        DrawUiText(text->footer, 24, 548, 15, (Color){ 133, 148, 172, 255 });
        EndDrawing();
    }

    if (translationThread != NULL) {
        WaitForSingleObject(translationThread, 35000);
        CloseHandle(translationThread);
        translationThread = NULL;
    }
    if (uiFont.texture.id != GetFontDefault().texture.id) {
        UnloadFont(uiFont);
    }
    UnloadImage(applicationIcon);
    StopOllamaServer();
    CloseWindow();
    return 0;
}

